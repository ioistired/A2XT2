local leafEmitter = particles.Emitter(0, 0, Misc.resolveFile("particles/p_leaf.ini"), 1)
leafEmitter:AttachToCamera(Camera.get()[1]);

function onCameraUpdate()
	if  player.section == 0  then
		leafEmitter:Draw();
	end
end